#include "main.h"

int hash_function(const char *word)
{
    char ch = tolower((unsigned char)word[0]);

    if (ch >= 'a' && ch <= 'z')
        return ch - 'a';

    return 26;
}

int insert_word(const char *word, const char *file_name)
{
    int index = hash_function(word);

    MainNode *main_temp = hashtable[index];
    MainNode *main_prev = NULL;

    while (main_temp != NULL)
    {
        if (strcmp(main_temp->word, word) == 0)
            break;

        main_prev = main_temp;
        main_temp = main_temp->main_link;
    }

    if (main_temp == NULL)
    {
        MainNode *new_main = malloc(sizeof(MainNode));

        if (new_main == NULL)
            return FAILURE;

        strcpy(new_main->word, word);
        new_main->file_count = 0;
        new_main->sub_link = NULL;
        new_main->main_link = NULL;

        if (main_prev == NULL)
            hashtable[index] = new_main;
        else
            main_prev->main_link = new_main;

        main_temp = new_main;
    }

    SubNode *sub_temp = main_temp->sub_link;
    SubNode *sub_prev = NULL;

    while (sub_temp != NULL)
    {
        if (strcmp(sub_temp->file_name, file_name) == 0)
        {
            sub_temp->word_count++;
            return SUCCESS;
        }

        sub_prev = sub_temp;
        sub_temp = sub_temp->sub_link;
    }

    SubNode *new_sub = malloc(sizeof(SubNode));

    if (new_sub == NULL)
        return FAILURE;

    strcpy(new_sub->file_name, file_name);
    new_sub->word_count = 1;
    new_sub->sub_link = NULL;

    if (sub_prev == NULL)
        main_temp->sub_link = new_sub;
    else
        sub_prev->sub_link = new_sub;

    main_temp->file_count++;

    return SUCCESS;
}
