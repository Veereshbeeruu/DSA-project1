#include "main.h"

int display_database(void)
{
    MainNode *main_temp;
    SubNode *sub_temp;

    printf("\nIndex\tWord\tFilecount\tFilename\tWordcount\n");

    for (int i = 0; i < SIZE; i++)
    {
        main_temp = hashtable[i];

        while (main_temp != NULL)
        {
            printf("[%d]\t%s\t%d\t\t",
                   i,
                   main_temp->word,
                   main_temp->file_count);

            sub_temp = main_temp->sub_link;

            while (sub_temp != NULL)
            {
                printf("%s\t%d\t",
                       sub_temp->file_name,
                       sub_temp->word_count);

                sub_temp = sub_temp->sub_link;
            }

            printf("\n");

            main_temp = main_temp->main_link;
        }
    }

    return SUCCESS;
}
