#include "main.h"

static void normalize_word(char *word)
{
    size_t len;

    // Convert to lowercase and remove punctuation from both ends of a token.
    for (size_t i = 0; word[i] != '\0'; i++)
        word[i] = (char)tolower((unsigned char)word[i]);

    while (word[0] != '\0' && ispunct((unsigned char)word[0]))
        memmove(word, word + 1, strlen(word));
// find the length of the word.
    len = strlen(word);
//Remove punctuation from the ending.    
    while (len > 0 && ispunct((unsigned char)word[len - 1]))
        word[--len] = '\0';
}

int create_database(void)
{
    FileList *file_temp = filelist_head;
    FILE *fp;
    char word[WORD_LEN];

    if (file_temp == NULL)
    {
        printf("No input files were supplied.\n");
        return FAILURE;
    }

    // Visit each validated input file in the file list.
    while (file_temp != NULL)
    {
        fp = fopen(file_temp->file_name, "r");
        if (fp == NULL)
        {
            perror(file_temp->file_name);
            file_temp = file_temp->link;
            continue;
        }

        // Read one whitespace-separated token at a time until EOF.
        while (fscanf(fp, "%99s", word) == 1)
        {
            normalize_word(word);

            // Ignore tokens that become empty after punctuation removal.
            if (word[0] != '\0')
            {
                if (insert_word(word, file_temp->file_name) == FAILURE)
                {
                    fclose(fp);
                    return FAILURE;
                }
            }
        }

        fclose(fp);
        file_temp = file_temp->link;
    }

    printf("Database created successfully.\n");
    return SUCCESS;
}

