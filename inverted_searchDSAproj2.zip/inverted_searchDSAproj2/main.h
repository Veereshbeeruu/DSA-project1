#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

#define SIZE 27
#define WORD_LEN 100
#define FILE_LEN 256
#define LINE_LEN 8192

#define SUCCESS 0
#define FAILURE -1

typedef struct subnode
{
    char file_name[FILE_LEN];
    int word_count;
    struct subnode *sub_link;
} SubNode;

typedef struct mainnode
{
    char word[WORD_LEN];
    int file_count;
    SubNode *sub_link;
    struct mainnode *main_link;
} MainNode;

typedef struct filelist
{
    char file_name[FILE_LEN];
    struct filelist *link;
} FileList;

extern MainNode *hashtable[SIZE];
extern FileList *filelist_head;

int validate_file(const char *file_name);
int add_file_to_list(const char *file_name);
int create_database(void);
int insert_word(const char *word, const char *file_name);
int display_database(void);
int search_database(const char *word);
int update_database(const char *backup_file);
int save_database(const char *backup_file);
int hash_function(const char *word);
void free_database(void);

#endif

