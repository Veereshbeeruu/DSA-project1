#include "main.h"

int save_database(const char *backup_file)
{
    FILE *fp = fopen(backup_file, "w");

    if (fp == NULL)
    {
        perror("Backup file");
        return FAILURE;
    }

    MainNode *main_temp;
    SubNode *sub_temp;

    for (int i = 0; i < SIZE; i++)
    {
        main_temp = hashtable[i];

        while (main_temp != NULL)
        {
            fprintf(fp, "#%d;%s;%d;",
                    i,
                    main_temp->word,
                    main_temp->file_count);

            sub_temp = main_temp->sub_link;

            while (sub_temp != NULL)
            {
                fprintf(fp, "%s;%d;",
                        sub_temp->file_name,
                        sub_temp->word_count);

                sub_temp = sub_temp->sub_link;
            }

            fprintf(fp, "#\n");

            main_temp = main_temp->main_link;
        }
    }

    fclose(fp);

    printf("Database saved successfully.\n");

    return SUCCESS;
}
