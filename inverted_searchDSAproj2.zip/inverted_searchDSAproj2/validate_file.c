#include "main.h"

int validate_file(const char *file_name)
{
    FILE *fp;

    int len = strlen(file_name);

    if (len < 5)
        return FAILURE;

    if (strcmp(file_name + len - 4, ".txt") != 0)
        return FAILURE;

    fp = fopen(file_name, "r");

    if (fp == NULL)
        return FAILURE;

    fclose(fp);

    return SUCCESS;
}
