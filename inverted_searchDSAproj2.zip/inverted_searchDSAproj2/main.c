#include "main.h"

MainNode *hashtable[SIZE] = {NULL};
FileList *filelist_head = NULL;

int main(int argc, char *argv[])
{
    int choice;
    char word[WORD_LEN];
    char backup_file[FILE_LEN];

    // Read and validate original text filenames from command-line arguments.
    if (argc < 2)
    {
        printf("Usage: %s file1.txt file2.txt ...\n", argv[0]);
        return FAILURE;
    }

    for (int i = 1; i < argc; i++)
    {
        if (validate_file(argv[i]) == SUCCESS)
        {
            if (add_file_to_list(argv[i]) == FAILURE)
            {
                printf("Unable to add %s\n", argv[i]);
                free_database();
                return FAILURE;
            }
        }
        else
        {
            printf("Skipping invalid file: %s\n", argv[i]);
        }
    }

    while (1)
    {
        printf("\n----- INVERTED SEARCH -----\n");
        printf("1. Create Database\n");
        printf("2. Display Database\n");
        printf("3. Search Word\n");
        printf("4. Save Database\n");
        printf("5. Update Database\n");
        printf("6. Exit\n");
        printf("Enter choice: ");

        if (scanf("%d", &choice) != 1)
        {
            printf("Invalid input\n");
            break;
        }

        switch (choice)
        {
            case 1:
                create_database();
                break;

            case 2:
                display_database();
                break;

            case 3:
                printf("Enter word to search: ");
                scanf("%99s", word);
                search_database(word);
                break;

            case 4:
                printf("Enter backup filename: ");
                scanf("%255s", backup_file);
                save_database(backup_file);
                break;

            case 5:
                printf("Enter backup filename: ");
                scanf("%255s", backup_file);
                update_database(backup_file);
                break;

            case 6:
                free_database();
                return SUCCESS;

            default:
                printf("Invalid choice\n");
        }
    }

    free_database();
    return FAILURE;
}

