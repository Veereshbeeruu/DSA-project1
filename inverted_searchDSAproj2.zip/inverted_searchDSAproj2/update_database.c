#include "main.h"

int update_database(const char *backup_file)
{
    FILE *fp = fopen(backup_file, "r");

    if (fp == NULL)
    {
        perror("Backup file");
        return FAILURE;
    }

    char line[LINE_LEN];
    char word[WORD_LEN];
    char file_name[FILE_LEN];
    char *token;

    while (fgets(line, sizeof(line), fp) != NULL)
    {
        token = strtok(line, ";");

        if (token == NULL || token[0] != '#')
            continue;

        int index = atoi(token + 1);

        token = strtok(NULL, ";");

        if (token == NULL || strlen(token) >= WORD_LEN)
        {
            fclose(fp);
            return FAILURE;
        }

        strcpy(word, token);

        token = strtok(NULL, ";");

        if (token == NULL || index != hash_function(word))
        {
            fclose(fp);
            return FAILURE;
        }

        int file_count = atoi(token);

        if (file_count < 0)
        {
            fclose(fp);
            return FAILURE;
        }

        for (int i = 0; i < file_count; i++)
        {
            token = strtok(NULL, ";");

            if (token == NULL || strlen(token) >= FILE_LEN)
            {
                fclose(fp);
                return FAILURE;
            }

            strcpy(file_name, token);

            token = strtok(NULL, ";");

            if (token == NULL)
            {
                fclose(fp);
                return FAILURE;
            }

            int count = atoi(token);

            if (count <= 0)
            {
                fclose(fp);
                return FAILURE;
            }

            for (int j = 0; j < count; j++)
            {
                if (insert_word(word, file_name) == FAILURE)
                {
                    fclose(fp);
                    return FAILURE;
                }
            }
        }
    }

    fclose(fp);

    printf("Database updated successfully.\n");

    return SUCCESS;
}
