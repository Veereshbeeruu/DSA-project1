#include "main.h"

int search_database(const char *word)
{
    char search_word[WORD_LEN];

    if (strlen(word) >= WORD_LEN)
        return FAILURE;

    strcpy(search_word, word);

    for (int i = 0; search_word[i] != '\0'; i++)
        search_word[i] = (char)tolower((unsigned char)search_word[i]);

    int index = hash_function(search_word);

    MainNode *main_temp = hashtable[index];

    while (main_temp != NULL)
    {
        if (strcmp(main_temp->word, search_word) == 0)
        {
            printf("\nWord found: %s\n", search_word);
            printf("File count: %d\n", main_temp->file_count);

            SubNode *sub_temp = main_temp->sub_link;

            while (sub_temp != NULL)
            {
                printf("%s : %d\n",
                       sub_temp->file_name,
                       sub_temp->word_count);

                sub_temp = sub_temp->sub_link;
            }

            return SUCCESS;
        }

        main_temp = main_temp->main_link;
    }

    printf("Word not found.\n");

    return FAILURE;
}
