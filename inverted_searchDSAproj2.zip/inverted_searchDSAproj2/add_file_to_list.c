#include "main.h"

int add_file_to_list(const char *file_name)
{
    FileList *temp = filelist_head;
    FileList *new;

    while (temp != NULL)
    {
        if (strcmp(temp->file_name, file_name) == 0)
            return FAILURE;

        temp = temp->link;
    }

    new = malloc(sizeof(FileList));

    if (new == NULL)
        return FAILURE;

    strcpy(new->file_name, file_name);

    new->link = NULL;

    if (filelist_head == NULL)
    {
        filelist_head = new;
    }
    else
    {
        temp = filelist_head;

        while (temp->link != NULL)
            temp = temp->link;

        temp->link = new;
    }

    return SUCCESS;
}
